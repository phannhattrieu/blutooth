package com.example.blutooth;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
;
import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button Discover, enable;
    private static final String TAG = "MainActivity";
    public static BluetoothService mBluetoothService;
    private final int PERMISSION_SCAN = 1;
    private final int PERMISSION_ADVERTISE = 2;

    @SuppressLint("HandlerLeak")

    private void hideKeybaord(View v) {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        } catch (Exception e) {
        }
    }

    void Mapping() {
        Discover = findViewById(R.id.btnFindUnpairedDevices);
        enable = findViewById(R.id.btnDiscoverable_on_off);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    void initPermission() {
        @SuppressLint("InlinedApi")
        String[] permission = new String[]{Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_ADVERTISE
        };
        requestPermissions(permission, 6);
    }

    @SuppressLint("HandlerLeak")
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mBluetoothService = new BluetoothService(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Mapping();
        initPermission();
        enable.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SupportAnnotationUsage")
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                btnEnableDisable_Discoverable();
            }
        });
        Discover.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SupportAnnotationUsage")
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                btn_Discover();
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void btnEnableDisable_Discoverable() {
        Log.d(TAG, "btnEnableDisable_Discoverable: Making device discoverable for 300 seconds.");
        if (checkSelfPermission(Manifest.permission.BLUETOOTH_ADVERTISE) != PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            @SuppressLint("InlinedApi")
            String[] permission = new String[]{Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_ADVERTISE
            };
            requestPermissions(permission, PERMISSION_ADVERTISE);
        } else {
            new Thread(new Runnable() {
                @SuppressLint("MissingPermission")
                @Override
                public void run() {
                    Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                    discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
                    startActivity(discoverableIntent);
                }
            }).start();
            Bundle bundle = new Bundle();
            bundle.putBoolean("connected", true);
            Intent intent1 = new Intent(MainActivity.this, GameActivity.class);
            intent1.putExtras(bundle);
            startActivity(intent1);
            mBluetoothService.start();
        }
    }


        @RequiresApi(api = Build.VERSION_CODES.M)
        void btn_Discover () {
            Log.d(TAG, "btnDiscover: Looking for unpaired devices.");
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                @SuppressLint("InlinedApi")
                String[] permission = new String[]{Manifest.permission.BLUETOOTH_CONNECT,
                        Manifest.permission.ACCESS_COARSE_LOCATION,
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.BLUETOOTH_SCAN,
                };
                requestPermissions(permission, PERMISSION_SCAN);
            } else {
                if (!mBluetoothService.mBluetoothAdapter.isEnabled()) {
                    new Thread(new Runnable() {
                        @SuppressLint("MissingPermission")
                        @Override
                        public void run() {
                            Intent enableBT = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                            startActivity(enableBT);
                        }
                    }).start();
                }
                Intent intent = new Intent(MainActivity.this, ListRomActivity.class);
                startActivity(intent);
            }
        }

        @RequiresApi(api = Build.VERSION_CODES.M)
        @SuppressLint("MissingPermission")
        @Override
        public void onRequestPermissionsResult ( int requestCode, @NonNull String[] permissions,
        @NonNull int[] grantResults){
            switch (requestCode) {
                case PERMISSION_ADVERTISE: {
                    List<String> temp = new ArrayList<>();
                    int count = 0;
                    for (int i = 0; i < grantResults.length; i++) {
                        if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                            temp.add(permissions[i]);
                            count++;
                        }
                    }
                    if (count > 0) {
                        String[] strArr = new String[temp.size()];
                        temp.toArray(strArr);
                        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
                        alertDialog.setTitle("Cảnh báo!");
                        alertDialog.setIcon(R.drawable.warning);
                        alertDialog.setMessage("Để chơi được game bạn cần phải cấp quyền!");
                        alertDialog.setPositiveButton("Đồng ý", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                requestPermissions(strArr, PERMISSION_SCAN);
                            }
                        });
                        alertDialog.setNegativeButton("Từ chối", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                        alertDialog.show();
                    } else {
                        Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
                        discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
                        startActivity(discoverableIntent);
                        mBluetoothService.start();
                    }
                }
                case PERMISSION_SCAN: {
                    List<String> temp = new ArrayList<>();
                    int count = 0;
                    for (int i = 0; i < grantResults.length; i++) {
                        if (grantResults[i] != PackageManager.PERMISSION_GRANTED) {
                            temp.add(permissions[i]);
                            count++;
                        }
                    }
                    if (count > 0) {
                        String[] strArr = new String[temp.size()];
                        temp.toArray(strArr);
                        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
                        alertDialog.setTitle("Cảnh báo!");
                        alertDialog.setIcon(R.drawable.warning);
                        alertDialog.setMessage("Để chơi được game bạn cần phải cấp quyền!");
                        alertDialog.setPositiveButton("Đồng ý", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                requestPermissions(strArr, PERMISSION_SCAN);
                            }
                        });
                        alertDialog.setNegativeButton("Từ chối", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                            }
                        });
                        alertDialog.show();
                    } else {
                        if (!mBluetoothService.mBluetoothAdapter.isEnabled()) {
                            Intent enableBT = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                            startActivity(enableBT);
                        }
                        Intent intent = new Intent(this, ListRomActivity.class);
                        startActivity(intent);
                    }
                }
                default:
                    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            }
        }
    }