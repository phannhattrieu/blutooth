package com.example.blutooth;

import android.widget.ImageView;

public class User {
    private String name;
    private ImageView picture;

    public User(String name, ImageView picture) {
        this.name = name;
        this.picture = picture;
    }

    public String getName() {
        return name;
    }

    public ImageView getPicture() {
        return picture;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPicture(ImageView picture) {
        this.picture = picture;
    }
}
